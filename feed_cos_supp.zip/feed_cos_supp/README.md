# Bias and high-dimensional adjustment in observational studies of peer effects
# Dean Eckles and Eytan Bakshy

## Supplementary Information
The Supplementary Information is in feed_cos_si_jasa.pdf.

## Reproducing the results
The provided R code can be run by using the targets in the provided
Makefile. For example: `make overall` will produce the main results
averaging over all domains. See `Makefile` for all targets.
